# `bmfrmtrig`
C-based trigonometric engines used in delay and sum beamforming

## Compilation and Instalation
These scripts should be installable on all systems with pip install. 

```
cd bmfrmtrig
pip install .
```

## Testing
Unit testing has not yet been impleemented. That will be next amjor update.

## Contributors
 - @wewightman: Owner and main distributor

